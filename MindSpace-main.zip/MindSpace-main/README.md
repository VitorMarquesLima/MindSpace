# MindSpace
Este foi um app construído com o objetivo de ajudar com sua saúde mental, utiliza python como principal linguagem e armazena os dados dos usuarios e conversas em um banco de dados na nuvem Azure! Deixei o passo a passo do codigo na pasta de documentação, está tudo muito bem especificado vale a pena a leitura!
